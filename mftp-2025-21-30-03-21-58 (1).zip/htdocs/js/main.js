document.addEventListener('DOMContentLoaded', function() {
    // Token copy functionality
    const tokenCopyBtn = document.getElementById('copy-token-btn');
    if (tokenCopyBtn) {
        tokenCopyBtn.addEventListener('click', function() {
            const tokenText = document.getElementById('token-text');
            if (tokenText) {
                navigator.clipboard.writeText(tokenText.value)
                    .then(() => {
                        // Success feedback
                        tokenCopyBtn.innerHTML = '<i class="fa fa-check"></i> Copied!';
                        setTimeout(() => {
                            tokenCopyBtn.innerHTML = '<i class="fa fa-copy"></i> Copy Token';
                        }, 2000);
                    })
                    .catch(err => {
                        console.error('Failed to copy: ', err);
                        alert('Failed to copy the token. Please try again.');
                    });
            }
        });
    }

    // Token revocation functionality
    const revokeTokenBtn = document.getElementById('revoke-token-btn');
    if (revokeTokenBtn) {
        revokeTokenBtn.addEventListener('click', function() {
            const tokenText = document.getElementById('token-text');
            if (tokenText && tokenText.value) {
                // Confirm revocation
                if (confirm('Are you sure you want to revoke this token? This action cannot be undone.')) {
                    revokeToken(tokenText.value);
                }
            } else {
                alert('No token to revoke.');
            }
        });
    }

    function revokeToken(token) {
        fetch('api/revoke_token.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token: token }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Success feedback
                alert('Token successfully revoked!');
                // Redirect to dashboard for a fresh token
                window.location.href = 'dashboard.php';
            } else {
                alert('Failed to revoke token: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while revoking the token.');
        });
    }

    // Token verification functionality
    const verifyTokenForm = document.getElementById('verify-token-form');
    if (verifyTokenForm) {
        verifyTokenForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const tokenText = document.getElementById('token-input').value;
            if (!tokenText) {
                alert('Please enter a token to verify.');
                return;
            }
            
            // Use AJAX to verify token
            verifyToken(tokenText);
        });
    }

    function verifyToken(token) {
        fetch('api/validate_token.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token: token }),
        })
        .then(response => response.json())
        .then(data => {
            const resultContainer = document.getElementById('token-verification-result');
            if (resultContainer) {
                if (data.valid) {
                    // Display token information
                    let html = `
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <strong>Valid Token</strong> - This token is authentic and has not been tampered with.
                        </div>
                        <div class="section">
                            <h3><i class="fas fa-list"></i> Token Contents</h3>
                            <div class="token-payload">`;
                    
                    // Add payload content
                    for (const [key, value] of Object.entries(data.payload)) {
                        const displayValue = (key === 'exp' || key === 'iat') 
                            ? new Date(value * 1000).toLocaleString() 
                            : value;
                        
                        html += `<div class="payload-item">
                                <span class="payload-key">${key}:</span>
                                <span class="payload-value">${displayValue}</span>
                            </div>`;
                    }
                    
                    html += `</div></div>`;
                    
                    resultContainer.innerHTML = html;
                } else {
                    resultContainer.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-times-circle"></i> <strong>Invalid Token</strong> - This token is invalid, has been tampered with, or has expired.
                        </div>`;
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            const resultContainer = document.getElementById('token-verification-result');
            if (resultContainer) {
                resultContainer.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> An error occurred while verifying the token.
                    </div>`;
            }
        });
    }

    // Token time remaining counter
    const tokenExpDisplay = document.getElementById('token-expiration-time');
    if (tokenExpDisplay) {
        const expTime = tokenExpDisplay.getAttribute('data-exp-time');
        if (expTime) {
            // Update the countdown every second
            const countdownTimer = setInterval(function() {
                const now = Math.floor(Date.now() / 1000);
                const timeLeft = parseInt(expTime) - now;
                
                if (timeLeft <= 0) {
                    clearInterval(countdownTimer);
                    tokenExpDisplay.innerHTML = '<span class="text-danger">Expired</span>';
                    return;
                }
                
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                tokenExpDisplay.textContent = `${minutes}m ${seconds}s`;
            }, 1000);
        }
    }
});