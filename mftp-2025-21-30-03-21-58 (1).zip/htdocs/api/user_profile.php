<?php
session_start();
require_once '../config.php';
require_once '../jwt_helper.php';

// Validate token from cookie
$token = $_COOKIE['auth_token'] ?? '';
$payload = validate_token($token);

if (!$payload) {
    $_SESSION['message'] = 'Unauthorized access. Please log in.';
    $_SESSION['message_type'] = 'danger';
    header('Location: ../dashboard.php');
    exit;
}

// Build profile info
$user_profile = [
    'ID' => $payload['sub'],
    'Username' => $payload['username'],
    'Role' => $payload['role'],
    'Issuer' => $payload['iss'],
    'Issued At' => date('Y-m-d H:i:s', $payload['iat']),
    'Expires At' => date('Y-m-d H:i:s', $payload['exp']),
    'Token ID (jti)' => $payload['jti']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light">
    <div class="container py-5">
        <h1 class="mb-4">User Profile</h1>

        <div class="card bg-secondary text-light">
            <div class="card-header">
                <h3><i class="fas fa-user"></i> Token-Based Profile</h3>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <?php foreach ($user_profile as $label => $value): ?>
                        <li class="list-group-item bg-dark text-light">
                            <strong><?php echo htmlspecialchars($label); ?>:</strong>
                            <?php echo htmlspecialchars($value); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="mt-4">
            <a href="../dashboard.php" class="btn btn-outline-light"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </div>

    <!-- Font Awesome (for icons) -->
    <script src="https://kit.fontawesome.com/a2e0f1c3e0.js" crossorigin="anonymous"></script>
</body>
</html>
