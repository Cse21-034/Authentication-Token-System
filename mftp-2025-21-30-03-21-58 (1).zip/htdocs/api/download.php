<?php
session_start();
require_once '../config.php';
require_once '../jwt_helper.php';

// Token validation
$token = $_COOKIE['auth_token'] ?? '';
$payload = validate_token($token);

if (!$payload) {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

if ($payload['role'] !== 'admin') {
    $_SESSION['message'] = 'Access denied. Admins only.';
    $_SESSION['message_type'] = 'danger';
    header("Location: ../index.php"); // ✅ Redirect instead of reload
    exit;
}

// File path (example: a PDF or zip)
$filename = 'confidential_guide.pdf';
$filepath = __DIR__ . '/../secure-files/' . $filename;

if (!file_exists($filepath)) {
    http_response_code(404);
    echo "File not found.";
    exit;
}

// Force download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
header('Content-Length: ' . filesize($filepath));
readfile($filepath);
exit;
