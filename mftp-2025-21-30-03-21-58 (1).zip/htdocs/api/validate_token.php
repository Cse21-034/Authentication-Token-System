<?php
// Set content type to JSON
header('Content-Type: application/json');

// Include necessary files
require_once '../config.php';
require_once '../jwt_helper.php';

// Get JSON input
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// Check if token is provided
if (!$data || !isset($data['token'])) {
    echo json_encode([
        'valid' => false,
        'message' => 'Token is required'
    ]);
    exit;
}

$token = $data['token'];

// Validate token
$payload = validate_token($token);

if ($payload) {
    // Format datetime fields for better readability
    if (isset($payload['iat'])) {
        $payload['iat'] = $payload['iat'];
    }
    if (isset($payload['exp'])) {
        $payload['exp'] = $payload['exp'];
    }
    
    echo json_encode([
        'valid' => true,
        'payload' => $payload
    ]);
} else {
    echo json_encode([
        'valid' => false,
        'message' => 'Invalid or expired token'
    ]);
}
?>