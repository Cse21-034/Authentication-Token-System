<?php
// Set content type to JSON
header('Content-Type: application/json');

// Start session to check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized: You must be logged in to revoke tokens'
    ]);
    exit;
}

// Include necessary files
require_once '../config.php';
require_once '../jwt_helper.php';

// Get JSON input
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// Check if token is provided
if (!$data || !isset($data['token'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Token is required'
    ]);
    exit;
}

$token = $data['token'];

// Blacklist token
$success = blacklist_token($token);

if ($success) {
    echo json_encode([
        'success' => true,
        'message' => 'Token has been revoked'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to revoke token'
    ]);
}
?>