document.addEventListener('DOMContentLoaded', function() {
    // Token copy functionality
    const tokenCopyBtn = document.getElementById('copy-token-btn');
    if (tokenCopyBtn) {
        tokenCopyBtn.addEventListener('click', function() {
            const tokenText = document.getElementById('token-text');
            if (tokenText) {
                navigator.clipboard.writeText(tokenText.value)
                    .then(() => {
                        // Success feedback
                        tokenCopyBtn.innerHTML = '<i class="fa fa-check"></i> Copied!';
                        setTimeout(() => {
                            tokenCopyBtn.innerHTML = '<i class="fa fa-copy"></i> Copy Token';
                        }, 2000);
                    })
                    .catch(err => {
                        console.error('Failed to copy: ', err);
                        alert('Failed to copy the token. Please try again.');
                    });
            }
        });
    }

    // Token revocation functionality
    const revokeTokenBtn = document.getElementById('revoke-token-btn');
    if (revokeTokenBtn) {
        revokeTokenBtn.addEventListener('click', function() {
            const tokenText = document.getElementById('token-text');
            if (tokenText && tokenText.value) {
                // Confirm revocation
                if (confirm('Are you sure you want to revoke this token? This action cannot be undone.')) {
                    revokeToken(tokenText.value);
                }
            } else {
                alert('No token to revoke.');
            }
        });
    }

    function revokeToken(token) {
        fetch('/api/revoke_token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token: token }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Success feedback
                alert('Token successfully revoked!');
                // Redirect to dashboard for a fresh token
                window.location.href = '/dashboard';
            } else {
                alert('Failed to revoke token: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while revoking the token.');
        });
    }

    // Token time remaining counter
    const tokenExpDisplay = document.getElementById('token-expiration-time');
    if (tokenExpDisplay) {
        const expTime = tokenExpDisplay.getAttribute('data-exp-time');
        if (expTime) {
            // Update the countdown every second
            const countdownTimer = setInterval(function() {
                const now = Math.floor(Date.now() / 1000);
                const timeLeft = parseInt(expTime) - now;
                
                if (timeLeft <= 0) {
                    clearInterval(countdownTimer);
                    tokenExpDisplay.innerHTML = '<span class="text-danger">Expired</span>';
                    return;
                }
                
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                tokenExpDisplay.textContent = `${minutes}m ${seconds}s`;
            }, 1000);
        }
    }
});
